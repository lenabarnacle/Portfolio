# currency_rates_loader

Загрузка курсов основных валют с cbr.ru